use crate::server::http2::frame::Http2ErrorCode;

/// Bảng tĩnh HPACK tiêu chuẩn (RFC 7541 Appendix A - 61 entries)
pub const STATIC_TABLE: &[(&str, &str)] = &[
    (":authority", ""),
    (":method", "GET"),
    (":method", "POST"),
    (":path", "/"),
    (":path", "/index.html"),
    (":scheme", "http"),
    (":scheme", "https"),
    (":status", "200"),
    (":status", "204"),
    (":status", "206"),
    (":status", "304"),
    (":status", "400"),
    (":status", "404"),
    (":status", "500"),
    ("accept-charset", ""),
    ("accept-encoding", "gzip, deflate"),
    ("accept-language", ""),
    ("accept-ranges", ""),
    ("accept", ""),
    ("access-control-allow-origin", ""),
    ("age", ""),
    ("allow", ""),
    ("authorization", ""),
    ("cache-control", ""),
    ("content-disposition", ""),
    ("content-encoding", ""),
    ("content-language", ""),
    ("content-length", ""),
    ("content-location", ""),
    ("content-range", ""),
    ("content-type", ""),
    ("cookie", ""),
    ("date", ""),
    ("etag", ""),
    ("expect", ""),
    ("expires", ""),
    ("from", ""),
    ("host", ""),
    ("if-match", ""),
    ("if-modified-since", ""),
    ("if-none-match", ""),
    ("if-range", ""),
    ("if-unmodified-since", ""),
    ("last-modified", ""),
    ("link", ""),
    ("location", ""),
    ("max-forwards", ""),
    ("proxy-authenticate", ""),
    ("proxy-authorization", ""),
    ("range", ""),
    ("referer", ""),
    ("refresh", ""),
    ("retry-after", ""),
    ("server", ""),
    ("set-cookie", ""),
    ("strict-transport-security", ""),
    ("transfer-encoding", ""),
    ("user-agent", ""),
    ("vary", ""),
    ("via", ""),
    ("www-authenticate", ""),
];

/// Quản lý Dynamic Table của HPACK
#[derive(Debug, Clone)]
pub struct DynamicTable {
    entries: Vec<(String, String)>,
    size: usize,
    max_size: usize,
}

impl DynamicTable {
    pub fn new(max_size: usize) -> Self {
        Self {
            entries: Vec::new(),
            size: 0,
            max_size,
        }
    }

    pub fn set_max_size(&mut self, new_max: usize) {
        self.max_size = new_max;
        self.evict_to_size(self.max_size);
    }

    pub fn insert(&mut self, name: String, value: String) {
        let entry_size = name.len() + value.len() + 32; // Overhead 32 bytes theo RFC 7541
        self.entries.insert(0, (name, value));
        self.size += entry_size;
        self.evict_to_size(self.max_size);
    }

    fn evict_to_size(&mut self, target_size: usize) {
        while self.size > target_size && !self.entries.is_empty() {
            if let Some((n, v)) = self.entries.pop() {
                let entry_size = n.len() + v.len() + 32;
                self.size = self.size.saturating_sub(entry_size);
            }
        }
    }

    pub fn get(&self, index: usize) -> Option<&(String, String)> {
        if index > 0 && index <= self.entries.len() {
            Some(&self.entries[index - 1])
        } else {
            None
        }
    }

    #[allow(dead_code)]
    pub fn len(&self) -> usize {
        self.entries.len()
    }
}

/// HPACK Decoder
pub struct HpackDecoder {
    dynamic_table: DynamicTable,
    max_dynamic_table_size: usize,
    max_header_block_size: usize,
}

impl HpackDecoder {
    pub fn new(max_dynamic_table_size: usize, max_header_block_size: usize) -> Self {
        Self {
            dynamic_table: DynamicTable::new(max_dynamic_table_size),
            max_dynamic_table_size,
            max_header_block_size,
        }
    }

    pub fn decode_header_block(
        &mut self,
        buf: &[u8],
    ) -> Result<Vec<(String, String)>, Http2ErrorCode> {
        if buf.len() > self.max_header_block_size {
            return Err(Http2ErrorCode::EnhanceYourCalm);
        }

        let mut pos = 0;
        let mut headers = Vec::new();

        while pos < buf.len() {
            let b = buf[pos];

            if (b & 0x80) != 0 {
                // 1. Indexed Header Field (1xxxxxxx)
                let (idx, bytes_read) = decode_int(&buf[pos..], 7)?;
                pos += bytes_read;

                let (name, val) = self.lookup_index(idx as usize)?;
                headers.push((name, val));
            } else if (b & 0x40) != 0 {
                // 2. Literal Header Field with Incremental Indexing (01xxxxxx)
                let (idx, bytes_read) = decode_int(&buf[pos..], 6)?;
                pos += bytes_read;

                let name = if idx == 0 {
                    let (s, bytes_read) = decode_string(&buf[pos..])?;
                    pos += bytes_read;
                    s
                } else {
                    self.lookup_index(idx as usize)?.0
                };

                let (value, bytes_read) = decode_string(&buf[pos..])?;
                pos += bytes_read;

                self.dynamic_table.insert(name.clone(), value.clone());
                headers.push((name, value));
            } else if (b & 0x20) != 0 {
                // 3. Dynamic Table Size Update (001xxxxx)
                let (new_max, bytes_read) = decode_int(&buf[pos..], 5)?;
                pos += bytes_read;
                let new_max =
                    usize::try_from(new_max).map_err(|_| Http2ErrorCode::CompressionError)?;
                if new_max > self.max_dynamic_table_size {
                    return Err(Http2ErrorCode::CompressionError);
                }
                self.dynamic_table.set_max_size(new_max);
            } else {
                // 4. Literal Header Field without / never Indexing (0000xxxx / 0001xxxx)
                let (idx, bytes_read) = decode_int(&buf[pos..], 4)?;
                pos += bytes_read;

                let name = if idx == 0 {
                    let (s, bytes_read) = decode_string(&buf[pos..])?;
                    pos += bytes_read;
                    s
                } else {
                    self.lookup_index(idx as usize)?.0
                };

                let (value, bytes_read) = decode_string(&buf[pos..])?;
                pos += bytes_read;

                headers.push((name, value));
            }
        }

        Ok(headers)
    }

    fn lookup_index(&self, index: usize) -> Result<(String, String), Http2ErrorCode> {
        if index == 0 {
            return Err(Http2ErrorCode::CompressionError);
        }

        if index <= STATIC_TABLE.len() {
            let (n, v) = STATIC_TABLE[index - 1];
            Ok((n.to_string(), v.to_string()))
        } else {
            let dyn_idx = index - STATIC_TABLE.len();
            if let Some((n, v)) = self.dynamic_table.get(dyn_idx) {
                Ok((n.clone(), v.clone()))
            } else {
                Err(Http2ErrorCode::CompressionError)
            }
        }
    }
}

/// HPACK Encoder
pub struct HpackEncoder {
    #[allow(dead_code)]
    dynamic_table: DynamicTable,
}

impl HpackEncoder {
    pub fn new(max_dynamic_table_size: usize) -> Self {
        Self {
            dynamic_table: DynamicTable::new(max_dynamic_table_size),
        }
    }

    pub fn encode_headers(&mut self, headers: &[(&str, &str)]) -> Vec<u8> {
        let mut out = Vec::new();

        for (name, value) in headers {
            let name_lower = name.to_lowercase();
            let mut matched_index = None;
            let mut name_index = None;

            // Search Static Table
            for (idx, &(s_name, s_val)) in STATIC_TABLE.iter().enumerate() {
                if s_name == name_lower {
                    if name_index.is_none() {
                        name_index = Some(idx + 1);
                    }
                    if s_val == *value {
                        matched_index = Some(idx + 1);
                        break;
                    }
                }
            }

            if let Some(idx) = matched_index {
                // Fully matched in static table -> Indexed Header Field
                encode_int(&mut out, 0x80, 7, idx as u64);
            } else if let Some(n_idx) = name_index {
                // Name matched in static table -> Literal Header without indexing
                encode_int(&mut out, 0x00, 4, n_idx as u64);
                encode_string(&mut out, value);
            } else {
                // Completely new name -> Literal Header with new name
                encode_int(&mut out, 0x00, 4, 0);
                encode_string(&mut out, &name_lower);
                encode_string(&mut out, value);
            }
        }

        out
    }
}

/// Helper: Decode variable-length integer (RFC 7541 Section 5.1)
pub fn decode_int(buf: &[u8], prefix_bits: usize) -> Result<(u64, usize), Http2ErrorCode> {
    if buf.is_empty() {
        return Err(Http2ErrorCode::CompressionError);
    }

    let mask = (1 << prefix_bits) - 1;
    let mut val = (buf[0] & mask) as u64;

    if val < mask as u64 {
        return Ok((val, 1));
    }

    let mut m = 0;
    let mut pos = 1;

    while pos < buf.len() {
        let b = buf[pos] as u64;
        let chunk = b & 0x7F;

        // Prevent shift overflow (m >= 64 would panic checked_shl, and shifting by > 63 overflows u64 anyway)
        if m >= 63 {
            return Err(Http2ErrorCode::CompressionError);
        }

        let shift_val = chunk
            .checked_shl(m)
            .ok_or(Http2ErrorCode::CompressionError)?;
        val = val
            .checked_add(shift_val)
            .ok_or(Http2ErrorCode::CompressionError)?;

        m += 7;
        pos += 1;
        if (b & 0x80) == 0 {
            return Ok((val, pos));
        }
    }

    Err(Http2ErrorCode::CompressionError)
}

/// Helper: Encode variable-length integer
pub fn encode_int(out: &mut Vec<u8>, prefix_mask: u8, prefix_bits: usize, value: u64) {
    let max_prefix = ((1 << prefix_bits) - 1) as u64;

    if value < max_prefix {
        out.push(prefix_mask | (value as u8));
    } else {
        out.push(prefix_mask | (max_prefix as u8));
        let mut rem = value - max_prefix;
        while rem >= 128 {
            out.push(((rem & 0x7F) as u8) | 0x80);
            rem >>= 7;
        }
        out.push(rem as u8);
    }
}

/// Helper: Decode string (Literal String)
fn decode_string(buf: &[u8]) -> Result<(String, usize), Http2ErrorCode> {
    if buf.is_empty() {
        return Err(Http2ErrorCode::CompressionError);
    }

    let is_huffman = (buf[0] & 0x80) != 0;
    let (str_len, bytes_read) = decode_int(buf, 7)?;

    // Safe length calculation preventing usize overflow panics
    let usize_str_len = usize::try_from(str_len).map_err(|_| Http2ErrorCode::CompressionError)?;
    let total_len = bytes_read
        .checked_add(usize_str_len)
        .ok_or(Http2ErrorCode::CompressionError)?;

    if buf.len() < total_len {
        return Err(Http2ErrorCode::CompressionError);
    }

    let str_bytes = &buf[bytes_read..total_len];

    let string_val = if is_huffman {
        decode_huffman(str_bytes)?
    } else {
        std::str::from_utf8(str_bytes)
            .map_err(|_| Http2ErrorCode::CompressionError)?
            .to_string()
    };

    Ok((string_val, total_len))
}

/// Helper: Encode uncompressed string
fn encode_string(out: &mut Vec<u8>, s: &str) {
    let bytes = s.as_bytes();
    encode_int(out, 0x00, 7, bytes.len() as u64);
    out.extend_from_slice(bytes);
}

/// Dynamic Huffman Tree Node
#[derive(Default)]
struct Node {
    symbol: Option<u16>,
    left: Option<usize>,
    right: Option<usize>,
}

/// Decode chuỗi Huffman tuân thủ RFC 7541 Appendix B theo Cây Nhị Phân chuẩn
fn decode_huffman(bytes: &[u8]) -> Result<String, Http2ErrorCode> {
    let mut nodes: Vec<Node> = vec![Node::default()];

    // Dựng cây nhị phân từ HUFFMAN_SPEC (257 entries chuẩn RFC 7541 Appendix B)
    for &(sym, code, bits) in HUFFMAN_SPEC {
        let mut curr = 0;
        for i in (0..bits).rev() {
            let bit = (code >> i) & 1;
            let next_idx = if bit == 0 {
                nodes[curr].left
            } else {
                nodes[curr].right
            };

            let next = match next_idx {
                Some(idx) => idx,
                None => {
                    let new_idx = nodes.len();
                    nodes.push(Node::default());
                    if bit == 0 {
                        nodes[curr].left = Some(new_idx);
                    } else {
                        nodes[curr].right = Some(new_idx);
                    }
                    new_idx
                }
            };
            curr = next;
        }
        nodes[curr].symbol = Some(sym);
    }

    let mut decoded = Vec::new();
    let mut curr = 0;
    let mut bits_since_symbol = 0;
    let mut trailing_bits_are_ones = true;

    for &byte in bytes {
        for bit_idx in (0..8).rev() {
            let bit = (byte >> bit_idx) & 1;
            let next = if bit == 0 {
                nodes[curr].left
            } else {
                nodes[curr].right
            };

            match next {
                Some(idx) => {
                    curr = idx;
                    bits_since_symbol += 1;
                    trailing_bits_are_ones &= bit == 1;
                    if let Some(sym) = nodes[curr].symbol {
                        if sym == 256 {
                            // EOS Symbol
                            return Err(Http2ErrorCode::CompressionError);
                        }
                        decoded.push(sym as u8);
                        curr = 0; // Trở về gốc cây
                        bits_since_symbol = 0;
                        trailing_bits_are_ones = true;
                    }
                }
                None => return Err(Http2ErrorCode::CompressionError),
            }
        }
    }

    // RFC 7541 only permits up to seven one-bits of EOS-prefix padding.
    if curr != 0 && (bits_since_symbol > 7 || !trailing_bits_are_ones) {
        return Err(Http2ErrorCode::CompressionError);
    }

    String::from_utf8(decoded).map_err(|_| Http2ErrorCode::CompressionError)
}

/// Complete 257-entry RFC 7541 Appendix B Huffman Code Table (Symbol, Code, Bits)
const HUFFMAN_SPEC: &[(u16, u32, u8)] = &[
    (0, 0x1ff8, 13),
    (1, 0x7fffd8, 23),
    (2, 0xfffffe2, 28),
    (3, 0xfffffe3, 28),
    (4, 0xfffffe4, 28),
    (5, 0xfffffe5, 28),
    (6, 0xfffffe6, 28),
    (7, 0xfffffe7, 28),
    (8, 0xfffffe8, 28),
    (9, 0xffffea, 24),
    (10, 0x3ffffffc, 30),
    (11, 0xfffffe9, 28),
    (12, 0xfffffea, 28),
    (13, 0x3ffffffd, 30),
    (14, 0xfffffeb, 28),
    (15, 0xfffffec, 28),
    (16, 0xfffffed, 28),
    (17, 0xfffffee, 28),
    (18, 0xfffffef, 28),
    (19, 0xffffff0, 28),
    (20, 0xffffff1, 28),
    (21, 0xffffff2, 28),
    (22, 0x3ffffffe, 30),
    (23, 0xffffff3, 28),
    (24, 0xffffff4, 28),
    (25, 0xffffff5, 28),
    (26, 0xffffff6, 28),
    (27, 0xffffff7, 28),
    (28, 0xffffff8, 28),
    (29, 0xffffff9, 28),
    (30, 0xffffffa, 28),
    (31, 0xffffffb, 28),
    (32, 0x14, 6),
    (33, 0x3f8, 10),
    (34, 0x3f9, 10),
    (35, 0xffa, 12),
    (36, 0x1ff9, 13),
    (37, 0x15, 6),
    (38, 0xf8, 8),
    (39, 0x7fa, 11),
    (40, 0x3fa, 10),
    (41, 0x3fb, 10),
    (42, 0xf9, 8),
    (43, 0x7fb, 11),
    (44, 0xfa, 8),
    (45, 0x16, 6),
    (46, 0x17, 6),
    (47, 0x18, 6),
    (48, 0x0, 5),
    (49, 0x1, 5),
    (50, 0x2, 5),
    (51, 0x19, 6),
    (52, 0x1a, 6),
    (53, 0x1b, 6),
    (54, 0x1c, 6),
    (55, 0x1d, 6),
    (56, 0x1e, 6),
    (57, 0x1f, 6),
    (58, 0x5c, 7),
    (59, 0xfb, 8),
    (60, 0x7ffc, 15),
    (61, 0x20, 6),
    (62, 0xffb, 12),
    (63, 0x3fc, 10),
    (64, 0x1ffa, 13),
    (65, 0x21, 6),
    (66, 0x5d, 7),
    (67, 0x5e, 7),
    (68, 0x5f, 7),
    (69, 0x60, 7),
    (70, 0x61, 7),
    (71, 0x62, 7),
    (72, 0x63, 7),
    (73, 0x64, 7),
    (74, 0x65, 7),
    (75, 0x66, 7),
    (76, 0x67, 7),
    (77, 0x68, 7),
    (78, 0x69, 7),
    (79, 0x6a, 7),
    (80, 0x6b, 7),
    (81, 0x6c, 7),
    (82, 0x6d, 7),
    (83, 0x6e, 7),
    (84, 0x6f, 7),
    (85, 0x70, 7),
    (86, 0x71, 7),
    (87, 0x72, 7),
    (88, 0xfc, 8),
    (89, 0x73, 7),
    (90, 0xfd, 8),
    (91, 0x1ffb, 13),
    (92, 0x7fff0, 19),
    (93, 0x1ffc, 13),
    (94, 0x3ffc, 14),
    (95, 0x22, 6),
    (96, 0x7ffd, 15),
    (97, 0x3, 5),
    (98, 0x23, 6),
    (99, 0x4, 5),
    (100, 0x24, 6),
    (101, 0x5, 5),
    (102, 0x25, 6),
    (103, 0x26, 6),
    (104, 0x27, 6),
    (105, 0x6, 5),
    (106, 0x74, 7),
    (107, 0x75, 7),
    (108, 0x28, 6),
    (109, 0x29, 6),
    (110, 0x2a, 6),
    (111, 0x7, 5),
    (112, 0x2b, 6),
    (113, 0x76, 7),
    (114, 0x2c, 6),
    (115, 0x8, 5),
    (116, 0x9, 5),
    (117, 0x2d, 6),
    (118, 0x77, 7),
    (119, 0x78, 7),
    (120, 0x79, 7),
    (121, 0x7a, 7),
    (122, 0x7b, 7),
    (123, 0x7ffe, 15),
    (124, 0x7fc, 11),
    (125, 0x3ffd, 14),
    (126, 0x1ffd, 13),
    (127, 0xffffffc, 28),
    (128, 0xfffe6, 20),
    (129, 0x3fffd2, 22),
    (130, 0xfffe7, 20),
    (131, 0xfffe8, 20),
    (132, 0x3fffd3, 22),
    (133, 0x3fffd4, 22),
    (134, 0x3fffd5, 22),
    (135, 0x7fffd9, 23),
    (136, 0x3fffd6, 22),
    (137, 0x7fffda, 23),
    (138, 0x7fffdb, 23),
    (139, 0x7fffdc, 23),
    (140, 0x7fffdd, 23),
    (141, 0x7fffde, 23),
    (142, 0xffffeb, 24),
    (143, 0x7fffdf, 23),
    (144, 0xffffec, 24),
    (145, 0xffffed, 24),
    (146, 0x3fffd7, 22),
    (147, 0x7fffe0, 23),
    (148, 0xffffee, 24),
    (149, 0x7fffe1, 23),
    (150, 0x7fffe2, 23),
    (151, 0x7fffe3, 23),
    (152, 0x7fffe4, 23),
    (153, 0x1fffdc, 21),
    (154, 0x3fffd8, 22),
    (155, 0x7fffe5, 23),
    (156, 0x3fffd9, 22),
    (157, 0x7fffe6, 23),
    (158, 0x7fffe7, 23),
    (159, 0xffffef, 24),
    (160, 0x3fffda, 22),
    (161, 0x1fffdd, 21),
    (162, 0xfffe9, 20),
    (163, 0x3fffdb, 22),
    (164, 0x3fffdc, 22),
    (165, 0x7fffe8, 23),
    (166, 0x7fffe9, 23),
    (167, 0x1fffde, 21),
    (168, 0x7fffea, 23),
    (169, 0x3fffdd, 22),
    (170, 0x3fffde, 22),
    (171, 0xfffff0, 24),
    (172, 0x1fffdf, 21),
    (173, 0x3fffdf, 22),
    (174, 0x7fffeb, 23),
    (175, 0x7fffec, 23),
    (176, 0x1fffe0, 21),
    (177, 0x1fffe1, 21),
    (178, 0x3fffe0, 22),
    (179, 0x1fffe2, 21),
    (180, 0x7fffed, 23),
    (181, 0x3fffe1, 22),
    (182, 0x7fffee, 23),
    (183, 0x7fffef, 23),
    (184, 0xfffea, 20),
    (185, 0x3fffe2, 22),
    (186, 0x3fffe3, 22),
    (187, 0x3fffe4, 22),
    (188, 0x7ffff0, 23),
    (189, 0x3fffe5, 22),
    (190, 0x3fffe6, 22),
    (191, 0x7ffff1, 23),
    (192, 0x3ffffe0, 26),
    (193, 0x3ffffe1, 26),
    (194, 0xfffeb, 20),
    (195, 0x7fff1, 19),
    (196, 0x3fffe7, 22),
    (197, 0x7ffff2, 23),
    (198, 0x3fffe8, 22),
    (199, 0x1ffffec, 25),
    (200, 0x3ffffe2, 26),
    (201, 0x3ffffe3, 26),
    (202, 0x3ffffe4, 26),
    (203, 0x7ffffde, 27),
    (204, 0x7ffffdf, 27),
    (205, 0x3ffffe5, 26),
    (206, 0xfffff1, 24),
    (207, 0x1ffffed, 25),
    (208, 0x7fff2, 19),
    (209, 0x1fffe3, 21),
    (210, 0x3ffffe6, 26),
    (211, 0x7ffffe0, 27),
    (212, 0x7ffffe1, 27),
    (213, 0x3ffffe7, 26),
    (214, 0x7ffffe2, 27),
    (215, 0xfffff2, 24),
    (216, 0x1fffe4, 21),
    (217, 0x1fffe5, 21),
    (218, 0x3ffffe8, 26),
    (219, 0x3ffffe9, 26),
    (220, 0xffffffd, 28),
    (221, 0x7ffffe3, 27),
    (222, 0x7ffffe4, 27),
    (223, 0x7ffffe5, 27),
    (224, 0xfffec, 20),
    (225, 0xfffff3, 24),
    (226, 0xfffed, 20),
    (227, 0x1fffe6, 21),
    (228, 0x3fffe9, 22),
    (229, 0x1fffe7, 21),
    (230, 0x1fffe8, 21),
    (231, 0x7ffff3, 23),
    (232, 0x3fffea, 22),
    (233, 0x3fffeb, 22),
    (234, 0x1ffffee, 25),
    (235, 0x1ffffef, 25),
    (236, 0xfffff4, 24),
    (237, 0xfffff5, 24),
    (238, 0x3ffffea, 26),
    (239, 0x7ffff4, 23),
    (240, 0x3ffffeb, 26),
    (241, 0x7ffffe6, 27),
    (242, 0x3ffffec, 26),
    (243, 0x3ffffed, 26),
    (244, 0x7ffffe7, 27),
    (245, 0x7ffffe8, 27),
    (246, 0x7ffffe9, 27),
    (247, 0x7ffffea, 27),
    (248, 0x7ffffeb, 27),
    (249, 0xffffffe, 28),
    (250, 0x7ffffec, 27),
    (251, 0x7ffffed, 27),
    (252, 0x7ffffee, 27),
    (253, 0x7ffffef, 27),
    (254, 0x7fffff0, 27),
    (255, 0x3ffffee, 26),
    (256, 0x3fffffff, 30),
];

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_decode_int_bounds() {
        // Safe integer decoding
        let buf = [0xFF, 0x01]; // prefix 0xFF (mask 127) -> 127 + 1 = 128
        let (val, len) = decode_int(&buf, 7).unwrap();
        assert_eq!(val, 128);
        assert_eq!(len, 2);

        // Malicious integer decoding (shift > 63)
        // 0x7F + 0x80 (128) shifted repeatedly
        let mut mal_buf = vec![0xFF];
        mal_buf.extend(std::iter::repeat_n(0xFF, 15)); // 15 * 7 = 105 shift
        mal_buf.push(0x01);
        let res = decode_int(&mal_buf, 7);
        assert_eq!(res, Err(Http2ErrorCode::CompressionError));
    }

    #[test]
    fn test_hpack_decode_string_boundary() {
        // String with declared length that overflows usize
        // e.g. length = u64::MAX
        let mut buf = vec![0x00]; // 0000000 (length starts here)
        buf[0] = 0x7F; // max prefix
        buf.extend(std::iter::repeat_n(0xFF, 9));
        buf.push(0x01); // terminates integer with high value
        let res = decode_string(&buf);
        assert_eq!(res, Err(Http2ErrorCode::CompressionError));
    }

    #[test]
    fn test_huffman_and_static_status_206() {
        // RFC 7541 C.4.1: "www.example.com" Huffman-coded.
        assert_eq!(
            decode_huffman(&[
                0xf1, 0xe3, 0xc2, 0xe5, 0xf2, 0x3a, 0x6b, 0xa0, 0xab, 0x90, 0xf4, 0xff
            ])
            .unwrap(),
            "www.example.com"
        );
        assert_eq!(STATIC_TABLE[9], (":status", "206"));
    }

    #[test]
    fn test_reject_oversized_dynamic_table_update() {
        let mut decoder = HpackDecoder::new(4096, 1024);
        // Dynamic table size update to 4097 (00111111, then 0xE2 0x1F).
        assert_eq!(
            decoder.decode_header_block(&[0x3f, 0xe2, 0x1f]),
            Err(Http2ErrorCode::CompressionError)
        );
    }
}
