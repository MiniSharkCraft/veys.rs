# `veysrs` (Vey Server.rs) - v0.3.0

Lightweight, multithreaded HTTP/1.1 Web Server written in pure Rust (Edition 2021) with 0 third-party web framework dependencies.

## 🚀 Key Features

- **100% Rust Standard Library**: Built using `std::net`, `std::thread`, `std::sync`, and `std::fs`.
- **Strict HTTP/1.1 Protocol**: Host header enforcement, method validation, Keep-Alive connection persistence & pipelining.
- **Resource Limits & Hardening**: Configurable limits for request size, URI length, header count, line size, and concurrent connection counts.
- **Per-Directory Hierarchy Rules (`.veysrule`)**: Modular INI-like configuration with inheritance, IP blocking (`DENY_IP`), custom headers (`HEADER`), 404 redirects (`REDIRECT_404`), and dotfile policy (`DENY_HIDDEN_FILES`).
- **Security Protections**: Double percent-encoding defense (`%252e%252e`), path traversal isolation, dotfile protection, and sanitized error responses.
- **Efficient Static File Serving**: Chunked streaming I/O for large files and zero-body `HEAD` metadata checks.
- **Multithreaded ThreadPool**: Worker thread pool with panic isolation (`catch_unwind`) and graceful shutdown.

## 🛠️ Build & Run

### Prerequisites
- Rust 1.70+ (`cargo`)

### Commands
```bash
# Check compilation
cargo check

# Run test suite
cargo test

# Launch server with default settings (http://127.0.0.1:8080)
cargo run

# Launch with CLI options
cargo run -- --host 127.0.0.1 --port 8080 --workers 8 --max-connections 1024 --dev
```

## ⚙️ `.veysrule` Syntax Example

```ini
# Root configuration for veysrs v0.3.0
PORT = 8080
ROOT_DIR = ./public

# Resource Limits
MAX_REQUEST_SIZE = 65536
MAX_HEADER_SIZE = 16384
MAX_HEADERS = 64
MAX_HEADER_LINE = 8192
MAX_URI_LENGTH = 8192

# Timeouts & Connection Pooling
READ_TIMEOUT = 10
WRITE_TIMEOUT = 10
KEEP_ALIVE_TIMEOUT = 10
MAX_CONNECTIONS = 1024
MAX_REQUESTS_PER_CONNECTION = 100

# Security & Policies
DENY_HIDDEN_FILES = true
DENY_IP = 192.168.1.50
HEADER = X-Powered-By: veysrs
REDIRECT_404 = /404.html
```

## 🔒 Security Model

- **Path Traversal Protection**: Rejects all path components escaping `ROOT_DIR` (e.g. `/../`, `/%2e%2e/`, `/%252e%252e/`).
- **Dotfile Protection**: When `DENY_HIDDEN_FILES = true`, restricts access to hidden files (`.veysrule`, `.git`, `.env`).
- **Error Sanitization**: Error responses present clean standard text without exposing internal server file paths.
